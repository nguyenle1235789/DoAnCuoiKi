package BEAN;

public class TestSheet {

	private int testid;
	private String datetimestart;
	private String datetimeend;
	private String time;
	private int number;
	private int testtypeid;
	private int subjectid;
	private int questiontypeid;
	private int classid;

	public int getTestid() {
		return testid;
	}

	public void setTestid(int testid) {
		this.testid = testid;
	}

	public String getDatetimestart() {
		return datetimestart;
	}

	public void setDatetimestart(String datetimestart) {
		this.datetimestart = datetimestart;
	}

	public String getDatetimeend() {
		return datetimeend;
	}

	public void setDatetimeend(String datetimeend) {
		this.datetimeend = datetimeend;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public int getTesttypeid() {
		return testtypeid;
	}

	public void setTesttypeid(int testtypeid) {
		this.testtypeid = testtypeid;
	}

	public int getSubjectid() {
		return subjectid;
	}

	public void setSubjectid(int subjectid) {
		this.subjectid = subjectid;
	}

	public int getQuestiontypeid() {
		return questiontypeid;
	}

	public void setQuestiontypeid(int questiontypeid) {
		this.questiontypeid = questiontypeid;
	}

	public int getClassid() {
		return classid;
	}

	public void setClassid(int classid) {
		this.classid = classid;
	}

}
