package BEAN;

public class ClassExam {

	private int classid;
	private String classname;
	private String subjectname;
	private String testtypemame;
	private int testid;

	public int getClassid() {
		return classid;
	}

	public void setClassid(int classid) {
		this.classid = classid;
	}

	public String getClassname() {
		return classname;
	}

	public void setClassname(String classname) {
		this.classname = classname;
	}

	public String getSubjectname() {
		return subjectname;
	}

	public void setSubjectname(String subjectname) {
		this.subjectname = subjectname;
	}

	public int getTestid() {
		return testid;
	}

	public void setTestid(int testid) {
		this.testid = testid;
	}

	public String getTesttypemame() {
		return testtypemame;
	}

	public void setTesttypemame(String testtypemame) {
		this.testtypemame = testtypemame;
	}
}
