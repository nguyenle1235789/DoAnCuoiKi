# timedquestions
A Javascript-based page for showing questions with a countdown clock.

This project was created for a debate with several actors, each one of them answering to a predefined set of questions within a limited amount of time.

To use it follow this steps:

* Download all the files in the project
* Edit `questions.js` and specify there your questions
* Open in a modern browser the `index.html` page
* The controls at the bottom of the page are intuitive, play with them!
