   var questions = [
        {
            'topic'     : 'Presentación candidatos',
            'question'  : 'Presentación libre',
            'time'      : 180
        },
        {
            'topic'     : 'Modelo de universidad',
            'question'  : '¿Preferencia a la estabilización o a la promoción?',
            'time'      : 90
        },
        {
            'topic'     : 'Modelo de universidad',
            'question'  : 'Cargos de gestión ¿excesivos? ¿qué medidas tomará?',
            'time'      : 90
        },
        {
            'topic'     : 'Docencia',
            'question'  : 'Medidas contra la mala práctica docente',
            'time'      : 90
        },
        {
            'topic'     : 'Docencia',
            'question'  : '24 créditos y pago de sexenios y quinquenios a PDI laboral ¿de dónde saldrá el dinero?',
            'time'      : 90
        },
        {
            'topic'     : 'Investigación',
            'question'  : '¿Cuál será su política con respecto a los Centros de Estudios Avanzados?',
            'time'      : 90
        },
        {
            'topic'     : 'Investigación',
            'question'  : '¿Qué nuevas líneas de investigación potenciará?',
            'time'      : 90
        },
        {
            'topic'     : 'Comunidad universitaria',
            'question'  : '¿Cuál va a ser el procedimiento de promoción para el PAS?',
            'time'      : 90
        },
        {
            'topic'     : 'Comunidad universitaria',
            'question'  : '¿Cuál será la primera medida respecto a PDI, PAS y estudiantes?',
            'time'      : 90
        },
        {
            'topic'     : 'Campus',
            'question'  : '¿Va a tomar medidas para la mejora del comedor universitario?',
            'time'      : 90
        },
        {
            'topic'     : 'Campus',
            'question'  : '¿Cómo piensa gestionar el Campus Científico-Tecnológico de Linares?',
            'time'      : 90
        },
        {
            'topic'     : 'Micrófono abierto',
            'question'  : 'Pregunta libre',
            'time'      : 60
        }
    ];